# RBAC 设计 v3.6.1

[设计文档与图稿](redesign/README.md)

[本轮整改与验证](implementation/整改报告-v3.6.1.md)
